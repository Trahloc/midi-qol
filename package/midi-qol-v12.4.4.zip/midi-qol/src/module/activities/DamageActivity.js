import { debugEnabled, warn } from "../../midi-qol.js";
import { configSettings } from "../settings.js";
import { MidiActivityMixin } from "./MidiActivityMixin.js";
export var MidiDamageActivity;
export var MidiDamageSheet;
export function setupDamageActivity() {
	if (debugEnabled > 0)
		warn("MidiQOL | DamageActivity | setupDamageActivity | Called");
	//@ts-expect-error
	const GameSystemConfig = game.system.config;
	//@ts-expect-error
	MidiDamageSheet = defineMidiDamageSheetClass(game.system.applications.activity.DamageSheet);
	MidiDamageActivity = defineMidiDamageActivityClass(GameSystemConfig.activityTypes.damage.documentClass);
	if (configSettings.replaceDefaultActivities) {
		GameSystemConfig.activityTypes["dnd5eDamage"] = GameSystemConfig.activityTypes.damage;
		GameSystemConfig.activityTypes.damage = { documentClass: MidiDamageActivity };
	}
	else {
		GameSystemConfig.activityTypes["midiDamage"] = { documentClass: MidiDamageActivity };
	}
}
let defineMidiDamageActivityClass = (ActivityClass) => {
	var _a, _b;
	return _a = class MidiDamageActivity extends (_b = MidiActivityMixin(ActivityClass)) {
			get isOtherActivityCompatible() { return true; }
			async rollDamage(config, dialog, message) {
				config.midiOptions ?? (config.midiOptions = {});
				config.midiOptions.fastForwardDamage = game.user?.isGM ? configSettings.gmAutoFastForwardDamage : ["all", "damage"].includes(configSettings.autoFastForward);
				return super.rollDamage(config, dialog, message);
			}
		},
		_a.LOCALIZATION_PREFIXES = [...Reflect.get(_b, "LOCALIZATION_PREFIXES", _a), "midi-qol.DAMAGE"],
		_a.metadata = foundry.utils.mergeObject(foundry.utils.mergeObject({}, Reflect.get(_b, "metadata", _a)), {
			title: "midi-qol.DAMAGE.Title.one",
			sheetClass: MidiDamageSheet,
			usage: {
				chatCard: "modules/midi-qol/templates/activity-card.hbs",
			},
		}, { overwrite: true }),
		_a;
};
export function defineMidiDamageSheetClass(baseClass) {
	var _a, _b;
	return _a = class MidiDamageSheet extends (_b = baseClass) {
		},
		_a.PARTS = {
			...Reflect.get(_b, "PARTS", _a),
			effect: {
				template: "modules/midi-qol/templates/activity/damage-effect.hbs",
				templates: [
					...Reflect.get(_b, "PARTS", _a).effect.templates,
					"modules/midi-qol/templates/activity/parts/use-condition.hbs",
				]
			}
		},
		_a;
}
