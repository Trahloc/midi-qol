/*
import { i18n } from "../../midi-qol"
import { configSettings, targetConfirmation } from "../settings";

export class TargetConfirmationConfig extends FormApplication {
constructor(object, options) {
	super(object, options)
}
static get defaultOptions(): any {
	return mergeObject(super.defaultOptions, {
	title: game.i18n.localize("midi-qol.ConfigTitle"),
	template: "modules/midi-qol/templates/lateTargetingConfig.html",
	id: "midi-qol-target-confirmation-config",
	width: 800,
	height: "auto",
	closeOnSubmit: false,
	scrollY: [".tab.workflow"],
	tabs: [{ navSelector: ".tabs", contentSelector: ".content", initial: "gm" }]
	})
}
async _updateObject(event, formData) {
	formData = expandObject(formData);
	let newSettings = mergeObject(targetConfirmation, formData, { overwrite: true, inplace: false })
	// const newSettings = mergeObject(configSettings, expand, {overwrite: true})
	if (game.user?.can("SETTINGS_MODIFY")) game.settings.set("midi-qol", "ConfigSettings", configSettings);
}
deffaultOptions() {
}
get title() {
	return i18n("midi-qol.ConfigTitle")
}

getData(options?: Application.RenderOptions | undefined): FormApplication.Data<{}, FormApplication.Options> | Promise<FormApplication.Data<{}, FormApplication.Options>> {
	const data = super.getData(options);
	return data;
}
protected _onSubmit(event: Event, options: any | undefined): Promise<Partial<Record<string, unknown>>> {
	return super._onSubmit(event, options);

}
}
*/ 
