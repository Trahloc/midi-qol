import { debugEnabled, warn } from "../../midi-qol.js";
import { ReplaceDefaultActivities, configSettings } from "../settings.js";
import { MidiActivityMixin } from "./MidiActivityMixin.js";
export var MidiHealActivity;
export var MidiHealSheet;
export function setupHealActivity() {
	if (debugEnabled > 0)
		warn("MidiQOL | HealActivity | setupHealActivity | Called");
	//@ts-expect-error
	const GameSystemConfig = game.system.config;
	//@ts-expect-error
	MidiHealSheet = defineMidiHealSheetClass(game.system.applications.activity.HealSheet);
	MidiHealActivity = defineMidiHealActivityClass(GameSystemConfig.activityTypes.heal.documentClass);
	if (ReplaceDefaultActivities) {
		GameSystemConfig.activityTypes["dnd5eHeal"] = GameSystemConfig.activityTypes.heal;
		GameSystemConfig.activityTypes.heal = { documentClass: MidiHealActivity };
	}
	else {
		GameSystemConfig.activityTypes["midiHeal"] = { documentClass: MidiHealActivity };
	}
}
let defineMidiHealActivityClass = (ActivityClass) => {
	var _a, _b;
	return _a = class MidiHealActivity extends (_b = MidiActivityMixin(ActivityClass)) {
			get isOtherActivityCompatible() { return true; }
			async rollDamage(config, dialog, message) {
				config.midiOptions ?? (config.midiOptions = {});
				config.midiOptions.fastForwardHeal = game.user?.isGM ? configSettings.gmAutoFastForwardDamage : ["all", "damage"].includes(configSettings.autoFastForward);
				config.midiOptions.fastForwardDamage = game.user?.isGM ? configSettings.gmAutoFastForwardDamage : ["all", "damage"].includes(configSettings.autoFastForward);
				return super.rollDamage(config, dialog, message);
			}
			async _triggerSubsequentActions(config, results) {
			}
		},
		_a.LOCALIZATION_PREFIXES = [...Reflect.get(_b, "LOCALIZATION_PREFIXES", _a), "midi-qol.HEAL"],
		_a.metadata = foundry.utils.mergeObject(foundry.utils.mergeObject({}, Reflect.get(_b, "metadata", _a)), {
			title: "midi-qol.HEAL.Title.one",
			sheetClass: MidiHealSheet,
			usage: {
				chatCard: "modules/midi-qol/templates/activity-card.hbs",
			},
		}, { overwrite: true }),
		_a;
};
export function defineMidiHealSheetClass(baseClass) {
	var _a, _b;
	return _a = class MidiHealSheet extends (_b = baseClass) {
		},
		_a.PARTS = {
			...Reflect.get(_b, "PARTS", _a),
			effect: {
				template: "modules/midi-qol/templates/activity/heal-effect.hbs",
				templates: [
					...Reflect.get(_b, "PARTS", _a).effect.templates,
					"modules/midi-qol/templates/activity/parts/use-condition.hbs",
				]
			}
		},
		_a;
}
