import { debugEnabled, warn } from "../../midi-qol.js";
import { ReplaceDefaultActivities } from "../settings.js";
import { asyncHooksCall } from "../utils.js";
import { MidiActivityMixin } from "./MidiActivityMixin.js";
export var MidiUtilityActivity;
export var MidiUtilitySheet;
export function setupUtilityActivity() {
	if (debugEnabled > 0)
		warn("MidiQOL | UtilityActivity | setupUtilityActivity | Called");
	//@ts-expect-error
	const GameSystemConfig = game.system.config;
	//@ts-expect-error
	MidiUtilitySheet = defineMidiUtilitySheetClass(game.system.applications.activity.UtilitySheet);
	MidiUtilityActivity = defineMidiUtilityActivityClass(GameSystemConfig.activityTypes.utility.documentClass);
	if (ReplaceDefaultActivities) {
		GameSystemConfig.activityTypes["dnd5eUtility"] = GameSystemConfig.activityTypes.utility;
		GameSystemConfig.activityTypes.utility = { documentClass: MidiUtilityActivity };
	}
	else {
		GameSystemConfig.activityTypes["midiUtility"] = { documentClass: MidiUtilityActivity };
	}
}
let defineMidiUtilityActivityClass = (ActvityClass) => {
	var _a, _b;
	return _a = class MidiUtilityActivity extends (_b = MidiActivityMixin(ActvityClass)) {
			get isOtherActivityCompatible() { return true; }
			async rollFormula(config, dialog, message = {}) {
				if (debugEnabled > 0)
					warn("UtilityActivity | rollFormula | Called", config, dialog, message);
				if (await asyncHooksCall("midi-qol.preFormulaRoll", this.workflow) === false
					|| await asyncHooksCall(`midi-qol.preFormulaRoll.${this.item.uuid}`, this.workflow) === false
					|| await asyncHooksCall(`midi-qol.preFormulaRoll.${this.uuid}`, this.workflow) === false) {
					console.warn("midi-qol | UtiliatyActivity | Formula roll blocked via pre-hook");
					return;
				}
				dialog.configure = !config.midiOptions.fastForwardDamage;
				Hooks.once("dnd5e.preRollDamageV2", (rollConfig, dialogConfig, messageConfig) => {
					delete rollConfig.event;
					return true;
				});
				message.create = false;
				let result = await super.rollFormula(config, dialog, message);
				// result = await postProcessUtilityRoll(this, config, result);
				if (config.midiOptions.updateWorkflow !== false && this.workflow) {
					this.workflow.utilityRolls = result;
					if (this.workflow.suspended)
						this.workflow.unSuspend.bind(this.workflow)({ utilityRoll: result, otherDamageRoll: this.workflow.otherDamageRoll });
				}
				return result;
			}
		},
		_a.metadata = foundry.utils.mergeObject(foundry.utils.mergeObject({}, Reflect.get(_b, "metadata", _a)), {
			title: "midi-qol.UTILITY.Title.one",
			sheetClass: MidiUtilitySheet,
			usage: {
				chatCard: "modules/midi-qol/templates/activity-card.hbs",
			},
		}, { overwrite: true }),
		_a;
};
export function defineMidiUtilitySheetClass(baseClass) {
	var _a, _b;
	return _a = class MidiUtilitySheet extends (_b = baseClass) {
		},
		_a.PARTS = {
			...Reflect.get(_b, "PARTS", _a),
			effect: {
				template: "modules/midi-qol/templates/activity/utility-effect.hbs",
				templates: [
					...Reflect.get(_b, "PARTS", _a).effect.templates,
					"modules/midi-qol/templates/activity/parts/use-condition.hbs",
				]
			}
		},
		_a;
}
