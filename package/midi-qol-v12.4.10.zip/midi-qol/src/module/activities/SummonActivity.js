import { debugEnabled, warn } from "../../midi-qol.js";
import { ReplaceDefaultActivities } from "../settings.js";
import { MidiActivityMixin } from "./MidiActivityMixin.js";
export var MidiSummonActivity;
export function setupSummonActivity() {
	if (debugEnabled > 0)
		warn("MidiQOL | SummonActivity | setupSummonActivity | Called");
	//@ts-expect-error
	const GameSystemConfig = game.system.config;
	MidiSummonActivity = defineMidiSummonActivityClass(GameSystemConfig.activityTypes.summon.documentClass);
	if (ReplaceDefaultActivities) {
		GameSystemConfig.activityTypes["dnd5eSummon"] = GameSystemConfig.activityTypes.summon;
		GameSystemConfig.activityTypes.summon = { documentClass: MidiSummonActivity };
	}
	else {
		GameSystemConfig.activityTypes["midiSummon"] = { documentClass: MidiSummonActivity };
	}
}
let defineMidiSummonActivityClass = (ActivityClass) => {
	var _a, _b;
	return _a = class MidiSummonActivity extends (_b = MidiActivityMixin(ActivityClass)) {
		},
		_a.LOCALIZATION_PREFIXES = [...Reflect.get(_b, "LOCALIZATION_PREFIXES", _a), "midi-qol.SUMMON"],
		_a.metadata = foundry.utils.mergeObject(foundry.utils.mergeObject({}, Reflect.get(_b, "metadata", _a)), {
			title: "midi-qol.SUMMON.Title.one",
			usage: {
				chatCard: "modules/midi-qol/templates/activity-card.hbs",
			},
		}, {}),
		_a;
};
