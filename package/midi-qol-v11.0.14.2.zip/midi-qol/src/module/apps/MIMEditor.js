import { debug } from "../../midi-qol.js";
export class MIMEditor extends FormApplication {
	/*
	Override
	*/
	static get defaultOptions() {
		return mergeObject(super.defaultOptions, {
			template: "./modules/midi-qol/templates/MIMEditor.html",
			classes: ["macro-sheet", "sheet", "mimeditor"]
		});
	}
	constructor(data, options) {
		super(data, options);
	}
	//@ts-expect-error getData
	getData(options = {}) {
		return mergeObject(super.getData(options), {
			macro: this.getMacro()
		});
	}
	/*
	Override
	*/
	async _updateObject(event, formData) {
		debug("MIMEditor | _updateObject  | ", { event, formData });
		await this.updateMacro(mergeObject(formData, { type: "script" }));
	}
	async updateMacro(args) {
		let { command, type } = args;
		let item = this.object;
		let macro = this.getMacro();
		debug("MIMEditor | updateMacro  | ", { command, type, item, macro });
		//@ts-expect-error .command
		if (macro.command != command)
			await this.setMacro(new Macro({
				name: item.name ?? "Item Macro",
				type: "script",
				scope: "global",
				command,
				author: game.user?.id,
			}, {}));
	}
	hasMacro() {
		const item = this.object;
		let flag = item.getFlag("dae", `macro`);
		debug("MIMEditor | hasMacro | ", { flag });
		return !!(flag?.command ?? flag?.data?.command);
	}
	getMacro() {
		const item = this.object;
		let flag = item.getFlag("dae", `macro`);
		debug("MIMEditor | getMacro | ", { flag });
		const command = flag?.command ?? "";
		return new Macro({ command, img: item.img, name: item.name, scope: "global", type: "script" }, {});
	}
	async setMacro(macro) {
		const item = this.object;
		let flag = item.getFlag("dae", `macro`);
		debug("MIMEditor | setMacro | ", { macro, flag });
		if (macro instanceof Macro) {
			const data = macro.toObject();
			return await item.setFlag("dae", `macro`, data);
		}
	}
}
